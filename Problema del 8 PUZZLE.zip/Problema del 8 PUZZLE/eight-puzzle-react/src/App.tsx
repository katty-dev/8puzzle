import React, { useState, useEffect, useCallback } from "react";
import "./App.css";
import { SqPuzzle } from "./SqPuzzle";
import { SqNode } from "./SqNode";

interface PuzzleState {
  board: number[][];
  zeroPos: { x: number; y: number };
  isSolved: boolean;
  isManuallySolved: boolean;
  manualMoves: number;
  solutionPath: number[][][];
  solutionMoves: number;
  nodesSearched: number;
  elapsedTime: number;
  totalManhattan: number;
  isAnimating: boolean;
  animationStep: number;
}

const App: React.FC = () => {
  const [puzzleState, setPuzzleState] = useState<PuzzleState>({
    board: [
      [1, 2, 3],
      [4, 5, 6],
      [7, 0, 8],
    ],
    zeroPos: { x: 2, y: 1 },
    isSolved: false,
    isManuallySolved: false,
    manualMoves: 0,
    solutionPath: [],
    solutionMoves: 0,
    nodesSearched: 0,
    elapsedTime: 0,
    totalManhattan: 0,
    isAnimating: false,
    animationStep: 0,
  });

  const [mode, setMode] = useState<"manual" | "auto">("manual");
  const [puzzle, setPuzzle] = useState<SqPuzzle | null>(null);

  useEffect(() => {
    if (
      puzzleState.board &&
      Array.isArray(puzzleState.board) &&
      puzzleState.board.length > 0
    ) {
      const newPuzzle = new SqPuzzle(puzzleState.board, puzzleState.zeroPos);
      setPuzzle(newPuzzle);
    } else {
      setPuzzle(null);
    }
  }, [puzzleState.board, puzzleState.zeroPos]);

  const displayBoard = (board: number[][]) => {
    if (!board || !Array.isArray(board)) {
      return <div>Error: Invalid board data</div>;
    }
    return board.map((row, i) => (
      <div key={i} className="row">
        {row.map((cell, j) => (
          <div
            key={j}
            className={`tile ${cell === 0 ? "empty" : ""}`}
            onClick={() => mode === "manual" && handleTileClick(i, j)}
          >
            {cell === 0 ? "" : cell}
          </div>
        ))}
      </div>
    ));
  };

  const handleTileClick = (x: number, y: number) => {
    const { zeroPos } = puzzleState;
    const dx = Math.abs(x - zeroPos.x);
    const dy = Math.abs(y - zeroPos.y);
    if ((dx === 1 && dy === 0) || (dx === 0 && dy === 1)) {
      handleMoveFromTile(x, y);
    }
  };

  const handleMoveFromTile = (x: number, y: number) => {
    const { zeroPos } = puzzleState;
    const newBoard = puzzleState.board.map((row) => [...row]);
    newBoard[zeroPos.x][zeroPos.y] = newBoard[x][y];
    newBoard[x][y] = 0;

    const isSolved = newBoard.every((row, i) =>
      row.every((cell, j) => cell === (i * 3 + j + 1) % 9)
    );

    setPuzzleState({
      ...puzzleState,
      board: newBoard,
      zeroPos: { x, y },
      isSolved,
    });
  };

  const handleMove = (direction: string) => {
    const { zeroPos } = puzzleState;
    let newZeroPos = { ...zeroPos };
    let validMove = false;

    switch (direction) {
      case "up":
        if (zeroPos.x > 0) {
          newZeroPos.x -= 1;
          validMove = true;
        }
        break;
      case "down":
        if (zeroPos.x < 2) {
          newZeroPos.x += 1;
          validMove = true;
        }
        break;
      case "left":
        if (zeroPos.y > 0) {
          newZeroPos.y -= 1;
          validMove = true;
        }
        break;
      case "right":
        if (zeroPos.y < 2) {
          newZeroPos.y += 1;
          validMove = true;
        }
        break;
    }

    if (validMove) {
      const newBoard = puzzleState.board.map((row) => [...row]);
      newBoard[zeroPos.x][zeroPos.y] = newBoard[newZeroPos.x][newZeroPos.y];
      newBoard[newZeroPos.x][newZeroPos.y] = 0;

      const isSolved = newBoard.every((row, i) =>
        row.every((cell, j) => cell === (i * 3 + j + 1) % 9)
      );

      setPuzzleState({
        ...puzzleState,
        board: newBoard,
        zeroPos: newZeroPos,
        isSolved,
      });
    }
  };

  const handleAutoSolve = useCallback(async () => {
    if (!puzzle) return;

    const startTime = performance.now();
    puzzle.solve();
    const endTime = performance.now();

    if (puzzle.solutionNode) {
      const path: number[][][] = [];
      let node: SqNode | null = puzzle.solutionNode;
      while (node) {
        path.unshift(node.position);
        node = node.theParent;
      }

      setPuzzleState((prevState) => ({
        ...prevState,
        solutionPath: path,
        solutionMoves: puzzle.solutionNode!.movesFromStart,
        nodesSearched: puzzle.nodesSearched,
        elapsedTime: (endTime - startTime) / 1000,
        totalManhattan: puzzle.solutionNode!.movesToGoal,
        isAnimating: true,
        animationStep: 0,
      }));

      // Start animation
      animateSolution(path);
    }
  }, [puzzle]);

  const animateSolution = (path: number[][][]) => {
    let step = 0;
    const interval = setInterval(() => {
      if (step < path.length) {
        const currentBoard = path[step];
        // Ensure board is valid before updating
        if (
          currentBoard &&
          Array.isArray(currentBoard) &&
          currentBoard.length === 3
        ) {
          setPuzzleState((prevState) => ({
            ...prevState,
            board: currentBoard,
            animationStep: step,
          }));
        }
        step++;
      } else {
        clearInterval(interval);
        setPuzzleState((prevState) => ({
          ...prevState,
          isAnimating: false,
          isSolved: true, // Mark as solved when animation completes
        }));
      }
    }, 500); // 500ms delay between steps
  };

  const shufflePuzzle = () => {
    const directions = ["up", "down", "left", "right"];
    let currentBoard = [
      [1, 2, 3],
      [4, 5, 6],
      [7, 0, 8],
    ];
    let currentZeroPos = { x: 2, y: 1 };

    // Perform 100 random moves to shuffle
    for (let i = 0; i < 100; i++) {
      const randomDirection =
        directions[Math.floor(Math.random() * directions.length)];
      let newZeroPos = { ...currentZeroPos };
      let validMove = false;

      switch (randomDirection) {
        case "up":
          if (currentZeroPos.x > 0) {
            newZeroPos.x -= 1;
            validMove = true;
          }
          break;
        case "down":
          if (currentZeroPos.x < 2) {
            newZeroPos.x += 1;
            validMove = true;
          }
          break;
        case "left":
          if (currentZeroPos.y > 0) {
            newZeroPos.y -= 1;
            validMove = true;
          }
          break;
        case "right":
          if (currentZeroPos.y < 2) {
            newZeroPos.y += 1;
            validMove = true;
          }
          break;
      }

      if (validMove) {
        const newBoard = currentBoard.map((row) => [...row]);
        newBoard[currentZeroPos.x][currentZeroPos.y] =
          newBoard[newZeroPos.x][newZeroPos.y];
        newBoard[newZeroPos.x][newZeroPos.y] = 0;
        currentBoard = newBoard;
        currentZeroPos = newZeroPos;
      }
    }

    setPuzzleState({
      board: currentBoard,
      zeroPos: currentZeroPos,
      isSolved: false,
      isManuallySolved: false,
      manualMoves: 0,
      solutionPath: [],
      solutionMoves: 0,
      nodesSearched: 0,
      elapsedTime: 0,
      totalManhattan: 0,
      isAnimating: false,
      animationStep: 0,
    });
  };

  const resetPuzzle = () => {
    setPuzzleState({
      board: [
        [1, 2, 3],
        [4, 5, 6],
        [7, 0, 8],
      ],
      zeroPos: { x: 2, y: 1 },
      isSolved: false,
      isManuallySolved: false,
      manualMoves: 0,
      solutionPath: [],
      solutionMoves: 0,
      nodesSearched: 0,
      elapsedTime: 0,
      totalManhattan: 0,
      isAnimating: false,
      animationStep: 0,
    });
  };

  if (puzzleState.isSolved) {
    return (
      <div className="App">
        <h1>Resolutor del 8-Puzzle</h1>
        <p>
          Esta aplicación demuestra el algoritmo A* con heurística de Manhattan
          para resolver el problema del 8-Puzzle.
        </p>

        <div className="win-message">
          <h2>¡Juego Completado!</h2>
          <p>El puzzle ha sido resuelto exitosamente.</p>
          <button onClick={shufflePuzzle}>Nuevo Juego</button>
        </div>
      </div>
    );
  }

  return (
    <div className="App">
      <div className="header-section">
        <h1>Resolutor del 8-Puzzle</h1>
        <p>
          Esta aplicación demuestra el algoritmo A* con heurística de Manhattan
          para resolver el problema del 8-Puzzle.
        </p>
      </div>

      <div className="controls-section">
        <div className="mode-controls">
          <button onClick={() => setMode("manual")}>Modo Manual</button>
          <button onClick={() => setMode("auto")}>Resolución con IA</button>
        </div>
        <div className="action-controls">
          <button onClick={shufflePuzzle}>Desordenar</button>
          <button onClick={resetPuzzle}>Reiniciar Puzzle</button>
        </div>
      </div>

      <div className="puzzle-container">
        <div className="puzzle-board">{displayBoard(puzzleState.board)}</div>
      </div>

      {puzzleState.solutionPath.length > 0 && !puzzleState.isAnimating && (
        <div className="solution-info">
          <h3>Solución Encontrada</h3>
          <p>
            <span className="metric-label">Movimientos realizados:</span>
            <span className="metric-value">{puzzleState.solutionMoves}</span>
          </p>
          <p>
            <span className="metric-label">Nodos explorados:</span>
            <span className="metric-value">{puzzleState.nodesSearched}</span>
          </p>
          <p>
            <span className="metric-label">Tiempo empleado:</span>
            <span className="metric-value">
              {puzzleState.elapsedTime.toFixed(2)} segundos
            </span>
          </p>
          <p>
            <span className="metric-label">Distancia Manhattan total:</span>
            <span className="metric-value">{puzzleState.totalManhattan}</span>
          </p>
        </div>
      )}

      {mode === "auto" && !puzzleState.isAnimating && (
        <button onClick={handleAutoSolve}>Resolver</button>
      )}

      {puzzleState.isAnimating && (
        <div className="animation-status">
          Animando solución... Paso {puzzleState.animationStep + 1} de{" "}
          {puzzleState.solutionPath.length}
        </div>
      )}
    </div>
  );
};

export default App;
