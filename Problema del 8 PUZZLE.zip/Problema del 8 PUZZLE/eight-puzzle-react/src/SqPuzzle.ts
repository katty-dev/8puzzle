import { SqNode } from "./SqNode";
import { width, prevPos, setWidth, resetPrevPos } from "./puzzleConfig";

export class SqPuzzle {
  public root: SqNode;
  public nodesSearched = 0;
  public solutionNode: SqNode | null = null;

  constructor(pos: number[][], zeroP: { x: number; y: number }) {
    setWidth(pos.length);
    if (pos[0].length !== width) {
      throw new Error("Puzzle not square");
    }
    this.root = new SqNode(pos, null, zeroP);
  }

  solve(): void {
    resetPrevPos();
    const graph = new Graph<SqNode>(
      this.root,
      (first, second) =>
        first.movesFromStart +
        first.movesToGoal -
        (second.movesFromStart + second.movesToGoal)
    );
    for (const node of graph.Astar()) {
      this.nodesSearched++;
      if (node.movesToGoal === 0) {
        this.solutionNode = node;
        break;
      }
    }
  }
}

class Graph<T extends IGNode<T>> {
  private root: T;
  private comparer: (a: T, b: T) => number;

  constructor(root: T, comparer: (a: T, b: T) => number) {
    this.root = root;
    this.comparer = comparer;
  }

  *Astar(): Generator<T> {
    const openSet = new PriorityQueue<T>((a, b) => this.comparer(a, b));
    const closedSet = new Set<T>();
    openSet.push(this.root);
    while (!openSet.isEmpty()) {
      const current = openSet.pop()!;
      closedSet.add(current);
      yield current;
      if (this.isGoal(current)) break;
      let child = current.firstChild();
      while (child) {
        if (!closedSet.has(child)) {
          openSet.push(child);
        }
        child = current.nextSibling();
      }
    }
  }

  private isGoal(node: T): boolean {
    return (node as any).movesToGoal === 0;
  }
}

class PriorityQueue<T> {
  private items: T[] = [];
  private compare: (a: T, b: T) => number;

  constructor(compare: (a: T, b: T) => number) {
    this.compare = compare;
  }

  push(item: T): void {
    this.items.push(item);
    this.items.sort(this.compare);
  }

  pop(): T | undefined {
    return this.items.shift();
  }

  isEmpty(): boolean {
    return this.items.length === 0;
  }
}

interface IGNode<T> {
  firstChild(): T | null;
  nextSibling(): T | null;
  occurred(): boolean;
  compareTo(other: T): number;
}
