import { width, prevPos, setWidth } from "./puzzleConfig";

export interface IGNode<T> {
  firstChild(): T | null;
  nextSibling(): T | null;
  occurred(): boolean;
  compareTo(other: T): number;
}

export class SqNode implements IGNode<SqNode> {
  public position: number[][];
  public zero: { x: number; y: number };
  public theParent: SqNode | null = null;
  public okMoves: { x: number; y: number }[] = [];
  public movesFromStart = 0;
  public movesToGoal = 0;

  constructor(
    positionP: number[][],
    par: SqNode | null,
    zeroP: { x: number; y: number }
  ) {
    setWidth(positionP.length);
    this.theParent = par;
    this.position = positionP;
    this.zero = zeroP;
    this.okMoves = this.generateMoves();
    if (par != null) this.movesFromStart = par.movesFromStart + 1;
    this.movesToGoal = this.getMovesToGoal();
  }

  getMovesToGoal(): number {
    let dist = 0;
    for (let i = 0; i < this.position.length; i++) {
      for (let j = 0; j < this.position[i].length; j++) {
        const hasValue = this.position[i][j];
        let goali: number, goalj: number;
        if (hasValue === 0) {
          goali = this.position.length - 1;
          goalj = this.position.length - 1;
        } else {
          goalj = (hasValue - 1) % this.position.length;
          goali = Math.floor((hasValue - 1) / this.position.length);
        }
        dist += Math.abs(i - goali) + Math.abs(j - goalj);
      }
    }
    return dist;
  }

  generateMoves(): { x: number; y: number }[] {
    const okMoves: { x: number; y: number }[] = [];
    if (this.zero.x - 1 >= 0)
      okMoves.push({ x: this.zero.x - 1, y: this.zero.y });
    if (this.zero.x + 1 < this.position.length)
      okMoves.push({ x: this.zero.x + 1, y: this.zero.y });
    if (this.zero.y - 1 >= 0)
      okMoves.push({ x: this.zero.x, y: this.zero.y - 1 });
    if (this.zero.y + 1 < this.position[0].length)
      okMoves.push({ x: this.zero.x, y: this.zero.y + 1 });
    return okMoves;
  }

  firstChild(): SqNode | null {
    if (this.movesToGoal === 0) return null;
    while (this.okMoves.length > 0) {
      const move = this.okMoves.shift()!;
      const child = new SqNode(this.makeMove(move), this, move);
      if (!child.occurred()) return child;
    }
    return null;
  }

  occurred(): boolean {
    if (this.movesToGoal === 0) return false;
    const hit = prevPos.findIndex((node) => node.compareTo(this) === 0);
    if (hit < 0) {
      prevPos.splice(~hit, 0, this);
      return false;
    }
    return true;
  }

  compareTo(other: SqNode): number {
    for (let i = 0; i < this.position.length; i++) {
      for (let j = 0; j < this.position[i].length; j++) {
        if (this.position[i][j] !== other.position[i][j]) {
          return this.position[i][j] - other.position[i][j];
        }
      }
    }
    return 0;
  }

  makeMove(move: { x: number; y: number }): number[][] {
    const newPos = this.position.map((row) => [...row]);
    newPos[this.zero.x][this.zero.y] = this.position[move.x][move.y];
    newPos[move.x][move.y] = 0;
    return newPos;
  }

  nextSibling(): SqNode | null {
    if (this.theParent == null) return null;
    while (this.theParent.okMoves.length > 0) {
      const move = this.theParent.okMoves.shift()!;
      const sib = new SqNode(
        this.theParent.makeMove(move),
        this.theParent,
        move
      );
      if (!sib.occurred()) return sib;
    }
    return null;
  }
}
