import { SqNode } from "./SqNode";

export let width = -1;
export let prevPos: SqNode[] = [];

export function setWidth(value: number) {
  width = value;
}

export function resetPrevPos() {
  prevPos.length = 0;
}
