using System;
using System.Collections.Generic;
using System.Drawing;

public interface IGNode<T> where T : IGNode<T>, IComparable<T>
{
    T firstChild();
    T nextSibling();
    bool occurred();
    int CompareTo(T other);
}

public class SqNode : IGNode<SqNode>, IComparable<SqNode>
{
    public int[,] position;
    public Point zero; //the empty space is at position[zero.X, zero.Y]
    public SqNode theParent = null;
    public List<Point> okMoves; //is ok to swap the zero and the points
    public int movesFromStart = 0; //same as this node’s “depth”
    public int movesToGoal = 0; //estimate based on heuristic

    public SqNode(int[,] positionP, SqNode par, Point zeroP)
    {
        if (SqPuzzle.width < 0)
            SqPuzzle.width = positionP.GetLength(0);

        theParent = par;
        position = positionP;
        zero = zeroP;

        okMoves = this.generateMoves();
        if (par != null)
            movesFromStart = par.movesFromStart + 1;
        movesToGoal = this.getMovesToGoal();
    }

    int getMovesToGoal()
    {
        //make optimistic estimate of number moves to the goal
        //we assume position is square
        int dist = 0;
        int goali, goalj, hasValue;
        for (int i = 0; i < position.GetLength(0); i++)
            for (int j = 0; j < position.GetLength(0); j++)
            {
                hasValue = position[i, j];

                if (hasValue == 0)
                {
                    //the "empty" square in the puzzle solution
                    goali = position.GetLength(0) - 1;
                    goalj = position.GetLength(0) - 1;
                }
                else
                {
                    goalj = (hasValue - 1) % position.GetLength(0);
                    goali = (hasValue - 1) / position.GetLength(0);
                }

                dist += Math.Abs(i - goali) + Math.Abs(j - goalj);
            }
        return dist;
    }

    public List<Point> generateMoves()
    {
        //legal swaps between the zero and adjacent squares
        List<Point> okMoves = new List<Point>(4);

        if (zero.X - 1 >= 0)
            okMoves.Add(new Point(zero.X - 1, zero.Y));
        if (zero.X + 1 < position.GetLength(0))
            okMoves.Add(new Point(zero.X + 1, zero.Y));

        if (zero.Y - 1 >= 0)
            okMoves.Add(new Point(zero.X, zero.Y - 1));
        if (zero.Y + 1 < position.GetLength(1))
            okMoves.Add(new Point(zero.X, zero.Y + 1));

        return okMoves;
    }

    public SqNode firstChild()
    {
        if (movesToGoal == 0)
            return null; //take no moves away from success

        while (okMoves.Count > 0)
        {
            Point move = okMoves[0];
            okMoves.RemoveAt(0);

            SqNode child = new SqNode(makeMove(move), this, move);
            if (!child.occurred()) //do not repeat a prev. position
                return child;
        }
        return null;
    }

    public bool occurred()
    {
        if (this.movesToGoal == 0) //do not keep solution from reoccurring
            return false;

        //if not already in prevPos, add it and return false.
        int hit = SqPuzzle.prevPos.BinarySearch(this);
        if (hit < 0)
        {
            hit = ~hit;
            SqPuzzle.prevPos.Insert(hit, this);
            return false;
        }
        return true;
    }

    public int CompareTo(SqNode other)
    {
        for (int i = 0; i < position.GetLength(0); i++)
            for (int j = 0; j < position.GetLength(1); j++)
            {
                if (position[i, j] != other.position[i, j])
                    return position[i, j].CompareTo(other.position[i, j]);
            }
        return 0;
    }

    public bool Equals(SqNode other)
    {
        if (other == this)
            return true;
        return (this.CompareTo(other) == 0);
    }

    public int[,] makeMove(Point move)
    {
        //return new position that results from current pos, taking move
        int[,] newPos = (int[,])position.Clone();
        newPos[zero.X, zero.Y] = position[move.X, move.Y];
        newPos[move.X, move.Y] = 0;
        return newPos;
    }

    public SqNode nextSibling()
    {
        if (theParent == null) //root has no sibs
            return null;

        while (theParent.okMoves.Count > 0)
        {
            Point move = theParent.okMoves[0];
            theParent.okMoves.RemoveAt(0);

            SqNode sib = new SqNode(theParent.makeMove(move), theParent, move);
            if (!sib.occurred()) //do not repeat a previous position
                return sib;
        }

        return null;
    }
}
