using System;
using System.Collections.Generic;
using System.Linq;

public class Graph<T> where T : IGNode<T>, IComparable<T>
{
    private T root;
    private Comparison<T> comparer;

    public Graph(T root, Comparison<T> comparer)
    {
        this.root = root;
        this.comparer = comparer;
    }

    public IEnumerable<T> Astar()
    {
        var openSet = new SortedSet<T>(Comparer<T>.Create(comparer));
        var closedSet = new HashSet<T>();
        var cameFrom = new Dictionary<T, T>();
        var gScore = new Dictionary<T, int>();
        var fScore = new Dictionary<T, int>();

        openSet.Add(root);
        gScore[root] = 0;
        fScore[root] = GetHeuristic(root);

        while (openSet.Count > 0)
        {
            T current = openSet.Min;
            openSet.Remove(current);
            closedSet.Add(current);

            yield return current;

            if (IsGoal(current))
                yield break;

            // Expand children
            T child = current.firstChild();
            while (child != null)
            {
                if (!closedSet.Contains(child))
                {
                    int tentativeGScore = gScore[current] + 1; // Assuming cost 1 per move

                    if (!openSet.Contains(child))
                        openSet.Add(child);
                    else if (tentativeGScore >= gScore.GetValueOrDefault(child, int.MaxValue))
                    {
                        child = current.nextSibling();
                        continue;
                    }

                    cameFrom[child] = current;
                    gScore[child] = tentativeGScore;
                    fScore[child] = gScore[child] + GetHeuristic(child);
                }

                child = current.nextSibling();
            }
        }
    }

    private int GetHeuristic(T node)
    {
        // For SqNode, heuristic is movesToGoal
        if (node is SqNode sqNode)
            return sqNode.movesToGoal;
        return 0;
    }

    private bool IsGoal(T node)
    {
        // For SqNode, goal is movesToGoal == 0
        if (node is SqNode sqNode)
            return sqNode.movesToGoal == 0;
        return false;
    }

    public bool quit(T node)
    {
        return node != null && IsGoal(node);
    }
}
