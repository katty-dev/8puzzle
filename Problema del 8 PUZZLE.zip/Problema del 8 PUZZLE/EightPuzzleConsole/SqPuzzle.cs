using System;
using System.Collections.Generic;
using System.Drawing;

public class SqPuzzle //Puzzle based on Sam Lloyd's "15 Puzzle"
{
    public SqNode root;
    public static int width = -1; //length of a side; puzzle is a square
    public static List<SqNode> prevPos = new List<SqNode>(10);
    public int nodesSearched = 0;
    public SqNode solutionNode = null;

    public SqPuzzle(int[,] pos, Point zeroP)
    {
        width = pos.GetLength(0);
        if (pos.GetLength(1) != width)
            throw new ApplicationException("puzzle not square");

        root = new SqNode(pos, null, zeroP);
    }

    public void solve()
    {
        Graph<SqNode> graph = new Graph<SqNode>(root,
            delegate (SqNode first, SqNode second)
            {
                return (first.movesFromStart + first.movesToGoal)
                    .CompareTo(second.movesFromStart + second.movesToGoal);
            });

        foreach (SqNode node in graph.Astar())
        {
            nodesSearched++;

            if (node.movesToGoal == 0) //solution node
            {
                if (solutionNode == null ||
                    solutionNode.movesFromStart > node.movesFromStart)
                    solutionNode = node;
            }
        }
    }
}
