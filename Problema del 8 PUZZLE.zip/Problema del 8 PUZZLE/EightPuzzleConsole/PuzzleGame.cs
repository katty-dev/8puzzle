using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;

public class PuzzleGame
{
    private SqPuzzle puzzle;
    private PuzzleUI ui;
    private SqNode currentNode;

    public PuzzleGame(int[,] initialBoard, Point zeroPosition)
    {
        puzzle = new SqPuzzle(initialBoard, zeroPosition);
        ui = new PuzzleUI();
        currentNode = puzzle.root;
    }

    public void PlayManual()
    {
        while (true)
        {
            ui.DisplayBoard(currentNode.position);

            if (currentNode.movesToGoal == 0)
            {
                ui.ShowWinMessage();
                break;
            }

            string move = ui.GetUserMove();
            if (move == "Q")
            {
                ui.ShowQuitMessage();
                break;
            }

            if (ui.IsValidMove(move, currentNode))
            {
                Point movePoint = ui.GetMovePoint(move, currentNode);
                int[,] newBoard = currentNode.makeMove(movePoint);
                currentNode = new SqNode(newBoard, currentNode, movePoint);
            }
            else
            {
                ui.ShowMessage("Invalid move. Try again.");
            }
        }
    }

    public void SolveAuto()
    {
        Stopwatch stopwatch = new Stopwatch();
        stopwatch.Start();

        puzzle.solve();

        stopwatch.Stop();

        Console.WriteLine($"Nodes searched: {puzzle.nodesSearched}");
        Console.WriteLine($"Time taken: {stopwatch.Elapsed.TotalSeconds} seconds");

        if (puzzle.solutionNode != null)
        {
            Console.WriteLine($"Solution found in {puzzle.solutionNode.movesFromStart} moves.");
            Console.WriteLine($"Total Manhattan distance: {puzzle.solutionNode.movesToGoal}");

            // Reconstruct path
            List<SqNode> path = new List<SqNode>();
            SqNode node = puzzle.solutionNode;
            while (node != null)
            {
                path.Insert(0, node);
                node = node.theParent;
            }

            Console.WriteLine("Solution path:");
            foreach (var step in path)
            {
                ui.DisplayBoard(step.position);
                Console.WriteLine("---");
            }
        }
        else
        {
            Console.WriteLine("No solution found.");
        }
    }
}
