using System;
using System.Drawing;

public class PuzzleUI
{
    public void DisplayBoard(int[,] board)
    {
        Console.Clear();
        int size = board.GetLength(0);
        for (int i = 0; i < size; i++)
        {
            for (int j = 0; j < size; j++)
            {
                int val = board[i, j];
                if (val == 0)
                    Console.Write("   ");
                else
                    Console.Write($"{val,2} ");
            }
            Console.WriteLine();
        }
        Console.WriteLine();
    }

    public string GetUserMove()
    {
        Console.Write("Enter move (W/A/S/D for up/left/down/right, or Q to quit): ");
        return Console.ReadLine().ToUpper();
    }

    public bool IsValidMove(string move, SqNode currentNode)
    {
        Point zero = currentNode.zero;
        switch (move)
        {
            case "W": // Up
                return zero.X > 0;
            case "S": // Down
                return zero.X < currentNode.position.GetLength(0) - 1;
            case "A": // Left
                return zero.Y > 0;
            case "D": // Right
                return zero.Y < currentNode.position.GetLength(1) - 1;
            default:
                return false;
        }
    }

    public Point GetMovePoint(string move, SqNode currentNode)
    {
        Point zero = currentNode.zero;
        switch (move)
        {
            case "W": // Up
                return new Point(zero.X - 1, zero.Y);
            case "S": // Down
                return new Point(zero.X + 1, zero.Y);
            case "A": // Left
                return new Point(zero.X, zero.Y - 1);
            case "D": // Right
                return new Point(zero.X, zero.Y + 1);
            default:
                throw new ArgumentException("Invalid move");
        }
    }

    public void ShowMessage(string message)
    {
        Console.WriteLine(message);
    }

    public void ShowWinMessage()
    {
        Console.WriteLine("Congratulations! You solved the puzzle!");
    }

    public void ShowQuitMessage()
    {
        Console.WriteLine("Game quit.");
    }
}
