using System;
using System.Drawing;

/*
 * 8-Puzzle Solver in C#
 *
 * The 8-Puzzle is a classic sliding puzzle consisting of a 3x3 grid with 8 numbered tiles and one empty space.
 * The goal is to arrange the tiles in numerical order (1-8) with the empty space in the bottom-right corner.
 *
 * Importance in AI: The 8-Puzzle is a fundamental problem in artificial intelligence, used to demonstrate search algorithms,
 * heuristics, and problem-solving techniques. It serves as a benchmark for evaluating the efficiency of different AI methods.
 *
 * Why A* is guaranteed to find the optimal solution: A* is an informed search algorithm that uses a heuristic function
 * to guide the search towards the goal. When the heuristic is admissible (never overestimates the true cost), A* is
 * guaranteed to find the optimal path if one exists. It combines the cost to reach the current node (g(n)) with the
 * estimated cost to the goal (h(n)), ensuring optimality.
 *
 * Manhattan Heuristic and Admissibility: The Manhattan distance heuristic calculates the sum of the absolute differences
 * in row and column positions between each tile's current position and its goal position. It is admissible because it
 * never overestimates the actual number of moves needed, as each tile can only move horizontally or vertically.
 *
 * Search Algorithm Comparisons:
 * - DFS (Depth-First Search): Explores as far as possible along each branch before backtracking. Can get stuck in deep paths,
 *   may not find the optimal solution, and is not complete for infinite state spaces.
 * - BFS (Breadth-First Search): Explores all nodes at the current depth before moving to the next level. Guarantees the
 *   shortest path in unweighted graphs but can be memory-intensive for large state spaces.
 * - Greedy Search: Uses only the heuristic to guide the search, always choosing the node with the lowest h(n). Fast but
 *   not optimal, as it may take suboptimal paths.
 * - A*: Combines BFS and Greedy by using f(n) = g(n) + h(n). Optimal and complete when the heuristic is admissible,
 *   more efficient than BFS for informed searches.
 *
 * This implementation uses the A* algorithm with Manhattan heuristic, following design patterns from "Design Patterns for Searching in C#".
 * Patterns used: Informed Search (A*), Node with Links (firstChild/nextSibling/parent), Backtracking, Node Expansion, Manhattan Heuristic.
 */

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("8-Puzzle Solver");
        Console.WriteLine("Choose mode:");
        Console.WriteLine("1. Manual (solve yourself)");
        Console.WriteLine("2. Auto (let AI solve)");
        string choice = Console.ReadLine();

        // Initial solvable 8-puzzle state
        int[,] initialBoard = {
            {1, 2, 3},
            {4, 0, 6},
            {7, 5, 8}
        };
        Point zeroPosition = new Point(1, 1); // Position of 0 (empty space)

        PuzzleGame game = new PuzzleGame(initialBoard, zeroPosition);

        if (choice == "1")
        {
            game.PlayManual();
        }
        else if (choice == "2")
        {
            game.SolveAuto();
        }
        else
        {
            Console.WriteLine("Invalid choice.");
        }
    }
}
